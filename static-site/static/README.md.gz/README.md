ARte-libs

# AR.js
https://github.com/jeromeetienne/AR.js

# PWA Compat
https://github.com/GoogleChromeLabs/pwacompat/blob/master/pwacompat.js

# A-Frame
https://github.com/aframevr/aframe/blob/master/dist/aframe-v0.8.2.js

# Gif Shader for A-Frame
https://github.com/tinchoforever/belisario.com.ar/blob/master/scripts/aframe-gif-shader.js

https://github.com/mayognaise/aframe-gif-shader